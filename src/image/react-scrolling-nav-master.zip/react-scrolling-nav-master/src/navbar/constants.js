export const OFFSET = -80;
export const DURATION = 500;
export const DELAY = 0;
export const NAV_WIDTH = 86;
export const LINK_CLASS = 'link';
export const ACTIVE_LINK_CLASS = 'active_link';
